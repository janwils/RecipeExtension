const recipe_selectors = [
    '.recipe-callout',
    '.tasty-recipes',
    '.easyrecipe',
    '.innerrecipe',
    '.recipe-summary.wide',
    '.wprm-recipe-container',
    '.recipe-content',
    '.simple-recipe-pro',
    '.mv-recipe-card',
    'div[itemtype="http://schema.org/Recipe"]',
    'div[itemtype="https://schema.org/Recipe"]',
    'div.recipediv',
];

// Headers to ignore
const ignoredSections = ["nutrition", "video", "reviews", "comments", "related", "faq", "notes", "tips"];

function removeExistingPopup() {
    let existingPopup = document.getElementById('_rf_highlight');
    if (existingPopup) existingPopup.remove();
}

function showPopup() {
    removeExistingPopup();

    let foundRecipe = false; // Track if a recipe is found

    recipe_selectors.every(function (s) {
        let original = document.querySelector(s);
        if (original) {
            foundRecipe = true; // A recipe has been found!

            let extractedContent = document.createElement("div");

            let sections = {};
            let currentHeader = null; 

            original.querySelectorAll("h2, h3, h4, p, ul, ol").forEach(el => {
                let text = el.innerText.trim();
                if (!text) return;

                if (el.tagName.toLowerCase().match(/^h[2-4]$/)) {
                    let lowerHeader = text.toLowerCase();

                    if (ignoredSections.some(keyword => lowerHeader.includes(keyword))) {
                        currentHeader = null; 
                    } else {
                        currentHeader = text;
                        sections[currentHeader] = [];
                    }
                } 
                else if (currentHeader) {
                    let cleanElement;
                    if (el.tagName.toLowerCase() === "p") {
                        cleanElement = document.createElement("p");
                    } else if (el.tagName.toLowerCase() === "ul") {
                        cleanElement = document.createElement("ul");
                    } else if (el.tagName.toLowerCase() === "ol") {
                        cleanElement = document.createElement("ol");
                    } else {
                        return;
                    }

                    el.querySelectorAll("li").forEach(li => {
                        let liText = li.innerText.trim();
                        if (liText) {
                            let cleanLi = document.createElement("li");
                            cleanLi.textContent = liText;
                            cleanElement.appendChild(cleanLi);
                        }
                    });

                    if (!cleanElement.hasChildNodes()) {
                        cleanElement.textContent = text;
                    }

                    sections[currentHeader].push(cleanElement);
                }
            });

            if (Object.keys(sections).length === 0) {
                alert("No recipe content found on this page.");
                return true;
            }

            Object.entries(sections).forEach(([header, elements]) => {
                let sectionHeader = document.createElement("h3");
                sectionHeader.textContent = header;
                extractedContent.appendChild(sectionHeader);
                elements.forEach(element => {
                    extractedContent.appendChild(element);
                });
            });

            let popup = document.createElement('div');
            popup.id = '_rf_highlight';
            popup.classList.add("_rf_popup");  
            popup.style.position = 'fixed';
            popup.style.top = '10%';
            popup.style.left = '50%';
            popup.style.transform = 'translate(-50%, 0)';
            popup.style.background = '#fff';
            popup.style.zIndex = '999999999';
            popup.style.boxShadow = '0px 4px 6px rgba(0, 0, 0, 0.41)';
            popup.style.maxWidth = '600px';
            popup.style.minWidth = '300px';
            popup.style.borderRadius = '10px';
            popup.style.fontFamily = "'Poppins', sans-serif";
            popup.style.fontSize = '16px';
            popup.style.color = '#333';
            popup.style.textAlign = 'left';
            popup.style.lineHeight = '1.5';
            popup.style.overflow = 'auto';
            popup.style.border = '2px solid black';
            popup.style.padding = '20px';
            popup.style.maxHeight = '80vh';  
            popup.style.overflowY = 'auto';  
            popup.style.overflowX = 'hidden'; 

            let headerContainer = document.createElement('div');
            headerContainer.style.display = 'flex';
            headerContainer.style.justifyContent = 'space-between';
            headerContainer.style.alignItems = 'center';
            headerContainer.style.borderBottom = '1px solid #ddd';
            headerContainer.style.paddingBottom = '8px';
            headerContainer.style.marginBottom = '12px';

            let title = document.createElement('h2');
            title.textContent = "Recipe Lens";
            title.style.margin = '0';
            title.style.flexGrow = '1';
            title.style.textAlign = 'center';

            let closeButton = document.createElement('button');
            closeButton.id = '_rf_closebtn';
            closeButton.classList.add('_rfbtn');
            closeButton.textContent = '✖';
            closeButton.style.cursor = 'pointer';
            closeButton.style.background = 'none';
            closeButton.style.border = 'none';
            closeButton.style.fontSize = '18px';
            closeButton.style.marginLeft = 'auto';
            closeButton.style.padding = '5px 10px';
            closeButton.style.color = '#FF3B30';
            closeButton.addEventListener('click', removeExistingPopup);

            headerContainer.appendChild(title);
            headerContainer.appendChild(closeButton);

            popup.appendChild(headerContainer);
            popup.appendChild(extractedContent);

            document.body.insertBefore(popup, document.body.firstChild);

            setTimeout(() => {
                popup.style.opacity = 1;
                document.scrollingElement.scrollTop = 0;
            }, 10);

            return false; 
        }
        return true; 
    });

    // **Show alert if no recipe was found**
    if (!foundRecipe) {
        alert("No recipe found on this page.");
    }
}

showPopup();
