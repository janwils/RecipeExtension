chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: extractRecipe
  });
});

async function extractRecipe() {
  const url = window.location.href;
  const response = await fetch("http://localhost:3000/extract", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url })
  });
  const data = await response.json();
  alert("Cleaned Recipe: \n" + data.recipe);
}