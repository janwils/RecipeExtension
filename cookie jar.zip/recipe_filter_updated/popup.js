document.addEventListener("DOMContentLoaded", function () {
    const tabExtract = document.getElementById("tabExtract");
    const tabSaved = document.getElementById("tabSaved");
    const extractContent = document.getElementById("extractContent");
    const savedContent = document.getElementById("savedContent");

    tabExtract.addEventListener("click", function () {
        tabExtract.classList.add("active");
        tabSaved.classList.remove("active");
        extractContent.classList.add("active");
        savedContent.classList.remove("active");
    });

    tabSaved.addEventListener("click", function () {
        tabExtract.classList.remove("active");
        tabSaved.classList.add("active");
        extractContent.classList.remove("active");
        savedContent.classList.add("active");
        loadSavedRecipes();
    });

    document.getElementById('openTab').addEventListener('click', function () {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                function: extractRecipe
            }, (results) => {
                if (chrome.runtime.lastError || !results || !results[0] || !results[0].result) {
                    chrome.storage.local.set({ extractedRecipe: "<p style='color: red;'>No recipe found.</p>" }, function () {
                        chrome.tabs.create({ url: chrome.runtime.getURL("newtab.html") });
                    });
                } else {
                    chrome.storage.local.set({ extractedRecipe: results[0].result }, function () {
                        chrome.tabs.create({ url: chrome.runtime.getURL("newtab.html") });
                    });
                }
            });
        });
    });

    function extractRecipe() {
        let recipeSelectors = [
            '.recipe-callout',
            '.tasty-recipes',
            '.easyrecipe',
            '.innerrecipe',
            '.recipe-summary.wide',
            '.wprm-recipe-container',
            '.recipe-content',
            '.simple-recipe-pro',
            '.mv-recipe-card',
            'div[itemtype="http://schema.org/Recipe"]',
            'div[itemtype="https://schema.org/Recipe"]',
            'div.recipediv'
        ];

        let ignoredSections = ["nutrition", "video", "reviews", "comments", "related", "faq", "notes", "tips"];

        let foundRecipe = false;
        let extractedHTML = "";

        let ingredients = [];
        let instructions = [];
        let additionalNotes = [];

        let currentSection = "other";

        recipeSelectors.every(selector => {
            let recipeElement = document.querySelector(selector);
            if (recipeElement) {
                foundRecipe = true;
                recipeElement.querySelectorAll("h2, h3, h4, p, ul, ol").forEach(el => {
                    let text = el.innerText.trim();
                    if (!text) return;

                    if (el.tagName.toLowerCase().match(/^h[2-4]$/)) {
                        let lowerHeader = text.toLowerCase();

                        if (ignoredSections.some(keyword => lowerHeader.includes(keyword))) {
                            currentSection = "other";
                        } else if (lowerHeader.includes("ingredient")) {
                            currentSection = "ingredients";
                        } else if (lowerHeader.includes("instruction") || lowerHeader.includes("directions") || lowerHeader.includes("steps")) {
                            currentSection = "instructions";
                        } else {
                            currentSection = "other";
                        }
                    } else {
                        if (el.tagName.toLowerCase() === "ul" || el.tagName.toLowerCase() === "ol") {
                            let listItems = [];
                            el.querySelectorAll("li").forEach(li => {
                                let liText = li.innerText.trim();
                                if (liText) listItems.push(`<li>${liText}</li>`);
                            });
                            if (listItems.length > 0) {
                                if (currentSection === "ingredients") {
                                    ingredients.push(...listItems);
                                } else if (currentSection === "instructions") {
                                    instructions.push(...listItems);
                                } else {
                                    additionalNotes.push(...listItems);
                                }
                            }
                        } else {
                            if (currentSection === "ingredients") {
                                ingredients.push(`<p>${text}</p>`);
                            } else if (currentSection === "instructions") {
                                instructions.push(`<p>${text}</p>`);
                            } else {
                                additionalNotes.push(`<p>${text}</p>`);
                            }
                        }
                    }
                });

                extractedHTML += `<h2>Ingredients</h2><ul>${ingredients.join('')}</ul>`;
                extractedHTML += `<h2>Instructions</h2><ol>${instructions.join('')}</ol>`;
                if (additionalNotes.length > 0) {
                    extractedHTML += `<h2>Additional Notes</h2><ul>${additionalNotes.join('')}</ul>`;
                }

                return false;
            }
            return true;
        });

        return foundRecipe ? extractedHTML : "<p>No recipe found on this page.</p>";
    }

    function loadSavedRecipes() {
        chrome.storage.local.get({ savedRecipes: [] }, function (items) {
            let savedRecipes = items.savedRecipes;
            let savedList = document.getElementById("savedRecipesList");
            savedList.innerHTML = "";

            if (savedRecipes.length === 0) {
                savedList.innerHTML = "<p>No saved recipes yet.</p>";
            } else {
                savedRecipes.forEach((recipe, index) => {
                    let recipeDiv = document.createElement("div");
                    recipeDiv.innerHTML = `<h3>Recipe #${index + 1} - ${recipe.date}</h3>${recipe.content}`;

                    let deleteButton = document.createElement("button");
                    deleteButton.textContent = "🗑 Delete";
                    deleteButton.addEventListener("click", function () {
                        savedRecipes.splice(index, 1);
                        chrome.storage.local.set({ savedRecipes: savedRecipes }, function () {
                            loadSavedRecipes(); // Refresh the saved list
                        });
                    });

                    recipeDiv.appendChild(deleteButton);
                    savedList.appendChild(recipeDiv);
                });
            }
        });
    }

    document.getElementById("clearRecipes").addEventListener("click", function () {
        chrome.storage.local.set({ savedRecipes: [] }, function () {
            loadSavedRecipes();
        });
    });
});
