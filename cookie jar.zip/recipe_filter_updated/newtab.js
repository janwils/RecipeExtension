document.addEventListener("DOMContentLoaded", function () {
    chrome.storage.local.get("extractedRecipe", function (data) {
        let recipeContent = document.getElementById("recipeContent");
        let recipeText = data.extractedRecipe || "<p>No recipe found.</p>";

        recipeContent.innerHTML = recipeText;

        let tempDiv = document.createElement("div");
        tempDiv.innerHTML = recipeText;
        let plainTextRecipe = tempDiv.innerText;

        document.getElementById("shareSMS").addEventListener("click", function () {
            let smsBody = encodeURIComponent(`Check out this recipe!\n\n${plainTextRecipe}`);
            window.location.href = `sms:?body=${smsBody}`;
        });

        document.getElementById("shareEmail").addEventListener("click", function () {
            let emailSubject = encodeURIComponent("Check out this recipe!");
            let emailBody = encodeURIComponent(plainTextRecipe);
            window.location.href = `mailto:?subject=${emailSubject}&body=${emailBody}`;
        });

        // Save Recipe
        document.getElementById("saveRecipe").addEventListener("click", function () {
            chrome.storage.local.get({ savedRecipes: [] }, function (items) {
                let recipes = items.savedRecipes;
                recipes.push({ content: recipeText, date: new Date().toLocaleString() });

                chrome.storage.local.set({ savedRecipes: recipes }, function () {
                    alert("Recipe saved successfully! 📂");
                });
            });
        });

        // View Saved Recipes
        document.getElementById("viewRecipes").addEventListener("click", function () {
            chrome.storage.local.get({ savedRecipes: [] }, function (items) {
                let savedRecipes = items.savedRecipes;
                let savedList = document.getElementById("savedRecipesList");
                savedList.innerHTML = "";

                if (savedRecipes.length === 0) {
                    savedList.innerHTML = "<p>No saved recipes yet.</p>";
                } else {
                    savedRecipes.forEach((recipe, index) => {
                        let recipeDiv = document.createElement("div");
                        recipeDiv.innerHTML = `<h3>Recipe #${index + 1} - ${recipe.date}</h3>${recipe.content}`;
                        
                        let deleteButton = document.createElement("button");
                        deleteButton.textContent = "🗑 Delete";
                        deleteButton.addEventListener("click", function () {
                            savedRecipes.splice(index, 1);
                            chrome.storage.local.set({ savedRecipes: savedRecipes }, function () {
                                document.getElementById("viewRecipes").click(); // Refresh the saved list
                            });
                        });

                        recipeDiv.appendChild(deleteButton);
                        savedList.appendChild(recipeDiv);
                    });
                }

                document.getElementById("savedRecipesPopup").classList.remove("hidden");
            });
        });

        // Close Saved Recipes Popup
        document.getElementById("closeSavedRecipes").addEventListener("click", function () {
            document.getElementById("savedRecipesPopup").classList.add("hidden");
        });
    });
});
